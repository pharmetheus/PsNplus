package PsNplus;

our $version;
#the version line is extracted in Makefile using regular expression
# /\$version\s*=\s*.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*.;/
# so be careful when you edit!!!
$version = '1.0.2';
